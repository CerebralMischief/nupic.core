import typedef_class

a = typedef_class.RealA() 
a.a = 3 
 
b = typedef_class.B() 
b.testA(a) 
