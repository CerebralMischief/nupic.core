from global_ns_arg import *

a = foo(1)
b = bar_fn()

