from overload_copy import *
f = Foo()
g = Foo(f)
