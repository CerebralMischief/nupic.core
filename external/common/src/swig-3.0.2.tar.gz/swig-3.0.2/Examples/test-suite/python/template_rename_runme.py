import template_rename

i = template_rename.iFoo()
d = template_rename.dFoo()

a = i.blah_test(4)
b = i.spam_test(5)
c = i.groki_test(6)

x = d.blah_test(7)
y = d.spam(8)
z = d.grok_test(9)
