import typemap_ns_using

if typemap_ns_using.spam(37) != 37:
    raise RuntimeError
