import template_ref_type

xr = template_ref_type.XC()
y  = template_ref_type.Y()
y.find(xr)
