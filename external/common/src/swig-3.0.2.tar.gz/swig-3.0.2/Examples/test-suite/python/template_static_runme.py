from template_static import  *

Foo_bar_double(1)
