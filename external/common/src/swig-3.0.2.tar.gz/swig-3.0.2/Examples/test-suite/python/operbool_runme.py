#!/usr/bin/env python
import operbool
assert not operbool.Test()

