import preproc_include

if preproc_include.multiply10(10) != 100:
  raise RuntimeError

if preproc_include.multiply20(10) != 200:
  raise RuntimeError

if preproc_include.multiply30(10) != 300:
  raise RuntimeError

if preproc_include.multiply40(10) != 400:
  raise RuntimeError

if preproc_include.multiply50(10) != 500:
  raise RuntimeError

if preproc_include.multiply60(10) != 600:
  raise RuntimeError

if preproc_include.multiply70(10) != 700:
  raise RuntimeError

