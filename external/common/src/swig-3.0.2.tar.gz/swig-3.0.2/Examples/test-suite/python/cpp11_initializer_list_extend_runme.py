import cpp11_initializer_list_extend

c = cpp11_initializer_list_extend.Container( [10, 20, 30, 40] )

