template_static

Foo_bar_double(1);
